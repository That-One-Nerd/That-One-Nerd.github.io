You are an employee working at Amazon. They are trying to automate their package selection system. You are asked to write a program that can find a package in their database by a given ID. The IDs will not be in chronological order and can be completely random. To compensate for this, they give you an array of the IDs that corresponds to the array of packages they give you. For example, in these two arrays:

```
  | IDs | Packages
------------------
0 | 653 | Package4
1 | 824 | Package2
2 | 001 | Package9
3 | 963 | Package1
4 | 876 | Package2
5 | 333 | Package5
```

package with ID 963 has an index of 3, which lets you know that it is package 9. You can find the correct package by calculating the index of the ID and then using that index to get the package.

You will be given an array of integers that represents the ID database, an array of strings that represents each Package's destination, and (*bonus*), an array of Package types that represents the properties of each package.

Your mission, should you choose to accept it:
1. Write a "Helper.java" class that contains code with the following methods:
    - `void updateDatabase(int[] ids, String[] packages)`
        - Update your database of IDs and package destinations.
    - `boolean containsId(int id)`
        - Check if the database of IDs contain the `id` parameter.
        - Returns `true` if the database of IDs does contain it, `false` otherwise.
    - `int[] GetAllIds()`
        - Returns all of the IDs in the database.
    - `String[] getAllPackages()`
        - Returns all of the packages in the database.
    - `String getPackage(int id)`
        - Get the package with a corresponding ID that is equal to `id`.
        - Returns the package's destination found in the string array.
    - `void updatePackage(int id, String newPackage)`
        - Replaces the destination of a package with a corresponding ID that is equal to `id` with `newPackage`.
2. *(Bonus) Write a class that contains the properties of a package. Name this class "Package.java"*
    - `String destination`
        - The destination of the package.
    - `int warehouseId`
        - The ID of the warehouse this package is stored in.
        - **The warehouse ID must be 3 digits long, no less, no more (unless it is -1).**
    - `double damage`
        - A number ranging from 0-100 percent representing the damage done to the box.
    - `double weight`
        - The weight of the package in kilograms.
    - `Package()`
        - Create a default instance of a package:
            - No destination ("")
            - No warehouse ID (-1)
            - Perfect condition, no damage (0)
            - No weight (0)
    - `Package(String destination)`
        - Create an instance of a package with a given destination:
            - Use `destination` as the destination
            - No warehouse ID (-1)
            - Perfect condition, no damage (0)
            - No weight (0)
    - `Package(String destination, double weight, double damage)`
        - Create an instance of a package with a given destination, weight, and damage.
            - Use `destination` as the destination
            - No warehouse ID (-1)
            - Use `damage` as the damage
            - Use `weight` as the weight
    - `Package(String destination, double weight, double damage, int warehouseId)`
        - Create an instance of a package with a given destination, weight, damage, and warehouse ID.
            - Use `destination` as the destination.
            - Use `warehouseId` as the warehouse ID.
            - Use `damage` as the damage.
            - Use `weight` as the weight.
    - `String getDestination()`
        - Returns the destination of the package.
    - `int getWarehouse()`
        - Returns the ID of the warehouse the package is located at.
    - `double getDamage()`
        - Returns the damage of the package.
    - `double getWeight()`
        - Returns the weight of the package.
    - `void redirectPackage(String newDestination)`
        - Sets a new destination for the package.
    - `void movePackage(int newWarehouseId)`
        - Sets a new warehouse ID for the package.
    - `void damage(double moreDamage)`
        - Deals additional damage to the package. The damage should not be negative and be bounded between 0 and 100.
    - `void addWeight(double moreWeight)`
        - Adds additional weight to the package. The weight should not be negative.
    - `boolean equals(Package other)`
        - Returns `true` if the two package instances have the same value, `false` otherwise.
3. *(Bonus) Write additional methods in the "Helper.java" class to use the package class*
    - `void updateDatabaseAll(int[] ids, String[] packages, Package[] properties)`
        - Update your database of IDs, destinations, and package properties.
    - `Package[] getAllProperties()`
        - Returns all of the properties in the database.
    - `Package getPackageProperties(int id)`
        - Get the Package properties of a package with ID `id`.
    - `void updatePackageProperties(int id, Package newPackage)`
        - Update your database with new properties for a package.
    - `void makeSmashed(int id)`
        - Make the package with an ID of `id` have a completely filled damage meter (100).
    - `void validateDestination(int id)`
        - Check if the destination in the array of destinations is the same as the destination in the properties of that package. If it isn't the same, set the property value to the array value.
