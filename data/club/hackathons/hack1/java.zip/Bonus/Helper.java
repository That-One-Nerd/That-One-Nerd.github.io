// The helper class for the first hackathon of the Programming Club.
// You probably shouldn't modify stuff that's already there for you.

public class Helper
{
    // The helper database. Only synced to the Runner's database by the
    // `updateDatabase(int[], String[])` and `updateDatabaseAll(int[], String[], Package[])` method.
    private static int[] ids = new int[0]; // The IDs of the packages.
    private static String[] packages = new String[0]; // The destinations of the packages.

    public static void updateDatabase(int[] ids, String[] packages)
    {
        // TODO
        // Update your database of IDs and package destinations.
    }

    public static void updateDatabaseAll(int[] ids, String[] destinations, Package[] packageProperties)
    {
        // TODO
        // Update your database of IDs, destinations, and package properties.
    }

    public static boolean containsId(int id)
    {
        // TODO
        // Check if the database of IDs contain the `id` parameter.
        // Returns `true` if the database of IDs does contain it, `false` otherwise.
    }

    public static int[] getAllIds()
    {
        // TODO
        // Returns all of the IDs in the database.
    }

    public static String[] getAllPackages()
    {
        // TODO
        // Returns all of the packages in the database.
    }

    public static Package[] getAllProperties()
    {
        // TODO
        // Returns all of the properties in the database.
    }
    
    public static String getPackage(int id)
    {
        // TODO
        // Get the package with a corresponding ID that is equal to `id`.
        // Returns the package's destination found in the string array.
    }

    public static Package getPackageProperties(int id)
    {
        // TODO
        // Get the Package properties of a package with ID `id`.
    }

    public static void makeSmashed(int id)
    {
        // TODO
        // Make the package with an ID of `id` have a completely filled damage meter (100).
    }

    public static void updatePackage(int id, String newPackage)
    {
        // TODO
        // Replaces the destination of a package with a corresponding ID that is equal to `id` with `newPackage`.
    }

    public static void updatePackageProperties(int id, Package newPackage)
    {
        // TODO
        // Update your database with new properties for a package.
    }

    public static void validateDestination(int id)
    {
        // TODO
        // Check if the destination in the array of destinations is the same as the destination in the properties
        // of that package. If it isn't the same, set the property value to the array value.
    }
}
