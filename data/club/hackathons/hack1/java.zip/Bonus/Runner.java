// The runner of the first hackathon for the Programming Club.
// DON'T MODIFY THIS!!!!!

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Runner
{
    private static final ArrayList<Integer> indexes = new ArrayList<Integer>();
    private static final ArrayList<String> destinations = new ArrayList<String>();
    private static final ArrayList<Package> properties = new ArrayList<Package>();
    
    private static final Random rand = new Random();

    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);

        System.out.println(
            "Available options:\n" +
            " - \"add\" - Add a new package. (Remember to update!)\n" +
            " - \"compare\" - Compare the Helper database to the true database.\n" +
            " - \"contains\" - Check if the database contains a package with a given ID.\n" +
            " - \"get dest\" - Get the destination of a package ID.\n" +
            " - \"package add weight\" - Adds weight to a package." +
            " - \"package damage\" - Damages a package." +
            " - \"package get damage\" - Gets the damage of a package by its properties." +
            " - \"package get dest\" - Gets the destination of a package by its properties." +
            " - \"package get warehouse\" - Gets the warehouse of a package by its properties." +
            " - \"package get weight\" - Gets the weight of a package by its properties." +
            " - \"package move\" - Moves a package to a different warehouse." +
            " - \"package redirect\" - Changes the destination of a package." +
            " - \"set dest\" - Update a package destination with a new one.\n" +
            " - \"smash\" - Smashes a package." +
            " - \"update\" - Updates the Helper with the new database.");

        while (true)
        {
            System.out.print("\n Enter option > ");
            String option = scan.nextLine();

            switch (option.trim().toLowerCase())
            {
                case "add":
                    int addId = randomId();
                    Package addPackage = randomPackage();

                    indexes.add(addId);
                    destinations.add(addPackage.getDestination());
                    properties.add(addPackage);

                    System.out.println("Added a new package with ID " + addId + " and delivery to " +
                                       addPackage.getDestination());
                    update();
                    break;

                case "compare":
                    int[] compareIds = Helper.getAllIds();
                    String[] compareDests = Helper.getAllPackages();
                    Package[] comparePacks = Helper.getAllProperties();

                    if (compareIds.length != compareDests.length || compareIds.length != comparePacks.length)
                    {
                        System.out.println("The ID count and the package count of the Helper database are not the same!");
                        continue;
                    }

                    if (compareIds.length > indexes.size())
                    {
                        System.out.println("Too many entries in the Helper database!");
                        continue;
                    }
                    else if (compareIds.length < indexes.size())
                    {
                        System.out.println("Missing " + (indexes.size() - compareIds.length) + " entries in the Helper database!");
                        continue;
                    }

                    for (int i = 0; i < compareIds.length; i++)
                    {
                        if (compareIds[i] != indexes.get(i))
                        {
                            System.out.println("Invalid index at index " + i + " in the Helper database.\n" +
                                               "Expected " + indexes.get(i) + ", got " + compareIds[i]);
                            continue;
                        }
                        else if (compareDests[i] != destinations.get(i))
                        {
                            System.out.println("Invalid destination at index " + i + " in the Helper database.\n" +
                                               "Expected \"" + destinations.get(i) + ",\" got \"" + compareDests[i] + "\"");
                            continue;
                        }
                        else if (!comparePacks[i].equals(properties.get(i)))
                        {
                            System.out.println("Invalid property at index " + i + " in the Helper database.");
                            continue;
                        }
                    }

                    System.out.println("Helper database is properly synced.");
                    break;

                case "contains":
                    System.out.print("Enter the ID to search for > ");

                    int containsId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    boolean containsResult = Helper.containsId(containsId);

                    if (containsResult) System.out.println("The helper database DOES contain a package with that ID.");
                    else System.out.println("The helper database does NOT contain a package with that ID.");
                    break;

                case "get dest":
                    System.out.print("Enter the ID to retrieve > ");

                    int getDestId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    String getDestResult = Helper.getPackage(getDestId);

                    System.out.println("Package with ID " + getDestId + " is for delivery to " + getDestResult);
                    break;

                case "package add weight":
                    System.out.print("Enter the ID to retrieve > ");
                           
                    int packageWeightId = scan.nextInt();
                    scan.nextLine(); // Java moment.
            
                    System.out.print("Enter the extra weight > ");
                    double packageWeightNew = scan.nextDouble();
                    scan.nextLine(); // Java moment.
            
                    Package packageWeightProperties = Helper.getPackageProperties(packageWeightId);
                    packageWeightProperties.addWeight(packageWeightNew);
                           
                    System.out.println("Gave package " + packageWeightId + " an additional " +
                                       packageWeightNew + " kilograms of weight.");
                    break;

                case "package damage":
                    System.out.print("Enter the ID to retrieve > ");
                       
                    int packageDamageId = scan.nextInt();
                    scan.nextLine(); // Java moment.
        
                    System.out.print("Enter the damage > ");
                    double packageDamageNew = scan.nextDouble();
                    scan.nextLine(); // Java moment.
        
                    Package packageDamageProperties = Helper.getPackageProperties(packageDamageId);
                    packageDamageProperties.damage(packageDamageNew);
                       
                    System.out.println("Damaged package " + packageDamageId + " by " +
                                       packageDamageNew + "%");
                    break;

                case "package get damage":
                    System.out.print("Enter the ID to retrieve > ");

                    int packageGetDamageId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    double packageGetDamageResult = Helper.getPackageProperties(packageGetDamageId).getDamage();

                    System.out.println("Package with ID " + packageGetDamageId +
                                       " is " + packageGetDamageResult + "% damaged.");
                    break;

                case "package get dest":
                    System.out.print("Enter the ID to retrieve > ");
    
                    int packageGetDestId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    String packageGetDestResult = Helper.getPackageProperties(packageGetDestId).getDestination();
    
                    System.out.println("Package with ID " + packageGetDestId +
                                       " is for delivery to " + packageGetDestResult);
                    break;

                case "package get warehouse":
                    System.out.print("Enter the ID to retrieve > ");
        
                    int packageGetWareId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    String packageGetWareResult = Helper.getPackageProperties(packageGetWareId).getDestination();
        
                    System.out.println("Package with ID " + packageGetWareId +
                                       " is in the warehouse with ID " + packageGetWareResult);
                    break;

                case "package get weight":
                    System.out.print("Enter the ID to retrieve > ");
            
                    int packageGetWeightId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    double packageGetWeightResult = Helper.getPackageProperties(packageGetWeightId).getWeight();
            
                    System.out.println("Package with ID " + packageGetWeightId +
                                       " weighs " + packageGetWeightResult + " kilograms.");
                    break;

                case "package move":
                    System.out.print("Enter the ID to retrieve > ");
                    
                    int packageMoveId = scan.nextInt();
                    scan.nextLine(); // Java moment.
    
                    System.out.print("Enter the new warehouse > ");
                    int packageMoveNew = scan.nextInt();
                    scan.nextLine(); // Java moment.
    
                    Package packageMoveProperties = Helper.getPackageProperties(packageMoveId);
                    packageMoveProperties.movePackage(packageMoveNew);
                    
                    System.out.println("Moved package " + packageMoveId + " to warehouse " +
                                       packageMoveNew);
                    break;

                case "package redirect":
                    System.out.print("Enter the ID to retrieve > ");
                
                    int packageRedirectId = scan.nextInt();
                    scan.nextLine(); // Java moment.

                    System.out.print("Enter the new destination > ");
                    String packageRedirectNew = scan.nextLine();

                    Package packageRedirectProperties = Helper.getPackageProperties(packageRedirectId);
                    packageRedirectProperties.redirectPackage(packageRedirectNew);
                
                    System.out.println("Changed the destination of package " + packageRedirectId + " to " +
                                       packageRedirectNew);
                    break;

                case "update":
                    update();
                    break;

                case "set dest":
                    System.out.print("Enter the ID to replace > ");

                    int setDestId = scan.nextInt();
                    scan.nextLine(); // Java moment.

                    System.out.print("Enter the new destination > ");
                    String setDestNew = scan.nextLine();

                    Helper.updatePackage(setDestId, setDestNew);
                    if (indexes.contains(setDestId)) destinations.set(indexes.indexOf(setDestId), setDestNew);

                    System.out.println("Replaced the destination for package " + setDestId + " to " + setDestNew);
                    break;

                case "smash":
                    System.out.print("Enter the ID to replace > ");

                    int smashId = scan.nextInt();
                    scan.nextLine(); // Java moment.

                    Helper.makeSmashed(smashId);
                    System.out.println("Smashed the package with ID " + smashId);
                    break;

                default:
                    System.out.println("Unknown option.");
                    continue;
            }
        }
    }

    private static void update()
    {
        // What a funny Java moment.
        int[] idArray = indexes.stream().mapToInt(Integer::intValue).toArray();
        String[] destArray = new String[destinations.size()];
        Package[] packArray = new Package[properties.size()];

        destinations.toArray(destArray);
        properties.toArray(packArray);
        Helper.updateDatabaseAll(idArray, destArray, packArray);

        System.out.println("Synced Helper database.");
    }

    private static final String[] streetNames =
    {
        "Mediterranean Avenue",
        "Baltic Avenue",
        "Oriental Avenue",
        "Vermont Avenue",
        "Connecticut Avenue",
        "St. Charles Place",
        "States Avenue",
        "Virginia Avenue",
        "St. James Place",
        "Tennessee Avenue",
        "New York Avenue",
        "Kentucky Avenue",
        "Indiana Avenue",
        "Illinois Avenue",
        "Atlantic Avenue",
        "Ventnor Avenue",
        "Marvin Gardins",
        "Pacific Avenue",
        "North Carolina Avenue",
        "Pennsylvania Avenue",
        "Park Place",
        "Boardwalk"
    };
    private static final String[] stateNames =
    {
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "District of Columbia",
        "Florida",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Puerto Rico",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Virgin Islands",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming"
    };

    private static int randomId()
    {
        return rand.nextInt(0, 1000);
    }
    private static Package randomPackage()
    {
        int warehouseId = randomId();
        double damage = rand.nextDouble() * 10,
               weight = rand.nextDouble() * 10;
        String destination = randomStreet();

        return new Package(destination, damage, weight, warehouseId);
    }
    private static String randomStreet()
    {
        int number = Math.abs(rand.nextInt(1, 10_000)),
            zip = Math.abs(rand.nextInt(10_000, 100_000));
        String street = streetNames[rand.nextInt(streetNames.length)],
               state = stateNames[rand.nextInt(stateNames.length)];

        return number + " " + street + ", " + state + " " + zip;
    }
}
