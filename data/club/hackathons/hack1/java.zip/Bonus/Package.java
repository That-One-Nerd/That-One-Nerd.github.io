// The package class for the first hackathon of the Programming Club

public class Package
{
    private String destination; // The destination of the package
    private int warehouseId; // The ID of the warehouse this package is stored in.
    // **The warehouse ID must be 3 digits long, no less, no more (unless it is -1).**
    private double damage; // A number ranging from 0-100 percent representing the damage done to the box.
    private double weight; // The weight of the package in kilograms.

    public Package()
    {
        // TODO
        // Create a default instance of a package:
        //     No destination ("")
        //     No warehouse ID (-1)
        //     Perfect condition, no damage (0)
        //     No weight (0)
    }
    public Package(String destination)
    {
        // TODO
        // Create an instance of a package with a given destination:
        //     Use `destination` as the destination
        //     No warehouse ID (-1)
        //     Perfect condition, no damage (0)
        //     No weight (0)
    }
    public Package(String destination, double damage, double weight)
    {
        // TODO
        // Create an instance of a package with a given destination, weight, and damage.
        //     Use `destination` as the destination
        //     No warehouse ID (-1)
        //     Use `damage` as the damage
        //     Use `weight` as the weight
    }
    public Package(String destination, double damage, double weight, int warehouseId)
    {
        // TODO
        // Create an instance of a package with a given destination, weight, damage, and warehouse ID.
        //     Use `destination` as the destination.
        //     Use `warehouseId` as the warehouse ID.
        //     Use `damage` as the damage.
        //     Use `weight` as the weight.
    }

    public String getDestination()
    {
        // TODO
        // Returns the destination of the package.
    }

    public int getWarehouse()
    {
        // TODO
        // Returns the ID of the warehouse the package is located at.
    }

    public double getDamage()
    {
        // TODO
        // Returns the damage of the package.
    }

    public double getWeight()
    {
        // TODO
        // Returns the weight of the package.
    }

    public void redirectPackage(String newDestination)
    {
        // TODO
        // Sets a new destination for the package.
    }

    public void movePackage(int newWarehouse)
    {
        // TODO
        // Sets a new warehouse ID for the package.
    }

    public void damage(double moreDamage)
    {
        // TODO
        // Deals additional damage to the package. The damage should not be negative and be bounded between 0 and 100.
    }

    public void addWeight(double moreWeight)
    {
        // TODO
        // Adds additional weight to the package. The weight should not be negative.
    }

    public boolean equals(Package other)
    {
        // TODO
        // Returns `true` if the two package instances have the same value, `false` otherwise.
    }
}
