// The runner of the first hackathon for the Programming Club.
// DON'T MODIFY THIS!!!!!

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Runner
{
    private static final ArrayList<Integer> indexes = new ArrayList<Integer>();
    private static final ArrayList<String> destinations = new ArrayList<String>();

    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);

        System.out.println(
            "Available options:\n" +
            " - \"add\" - Add a new package. (Remember to update!)\n" +
            " - \"compare\" - Compare the Helper database to the true database.\n" +
            " - \"contains\" - Check if the database contains a package with a given ID.n" +
            " - \"get dest\" - Get the destination of a package ID.\n" +
            " - \"update\" - Updates the Helper with the new database.\n" +
            " - \"set dest\" - Update a package destination with a new one.");

        while (true)
        {
            System.out.print("\n Enter option > ");
            String option = scan.nextLine();

            switch (option.trim().toLowerCase())
            {
                case "add":
                    int addId = randomId();
                    String addDest = randomStreet();

                    indexes.add(addId);
                    destinations.add(addDest);

                    System.out.println("Added a new package with ID " + addId + " and delivery to " + addDest);
                    update();
                    break;

                case "compare":
                    int[] compareIds = Helper.getAllIds();
                    String[] compareDests = Helper.getAllPackages();

                    if (compareIds.length != compareDests.length)
                    {
                        System.out.println("The ID count and the package count of the Helper database are not the same!");
                        continue;
                    }

                    if (compareIds.length > indexes.size())
                    {
                        System.out.println("Too many entries in the Helper database!");
                        continue;
                    }
                    else if (compareIds.length < indexes.size())
                    {
                        System.out.println("Missing " + (indexes.size() - compareIds.length) + " entries in the Helper database!");
                        continue;
                    }

                    for (int i = 0; i < compareIds.length; i++)
                    {
                        if (compareIds[i] != indexes.get(i))
                        {
                            System.out.println("Invalid index at index " + i + " in the Helper database.\n" +
                                               "Expected " + indexes.get(i) + ", got " + compareIds[i]);
                            continue;
                        }
                        else if (compareDests[i] != destinations.get(i))
                        {
                            System.out.println("Invalid destination at index " + i + " in the Helper database.\n" +
                                               "Expected \"" + destinations.get(i) + ",\" got \"" + compareDests[i] + "\"");
                            continue;
                        }
                    }

                    System.out.println("Helper database is properly synced.");
                    break;

                case "contains":
                    System.out.print("Enter the ID to search for > ");

                    int containsId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    boolean containsResult = Helper.containsId(containsId);

                    if (containsResult) System.out.println("The helper database DOES contain a package with that ID.");
                    else System.out.println("The helper database does NOT contain a package with that ID.");
                    break;

                case "get dest":
                    System.out.print("Enter the ID to retrieve > ");

                    int getDestId = scan.nextInt();
                    scan.nextLine(); // Java moment.
                    String getDestResult = Helper.getPackage(getDestId);

                    System.out.println("Package with ID " + getDestId + " is for delivery to " + getDestResult);
                    break;

                case "update":
                    update();
                    break;

                case "set dest":
                    System.out.print("Enter the ID to replace > ");

                    int setDestId = scan.nextInt();
                    scan.nextLine(); // Java moment.

                    System.out.print("Enter the new destination > ");
                    String setDestNew = scan.nextLine();

                    Helper.updatePackage(setDestId, setDestNew);
                    if (indexes.contains(setDestId)) destinations.set(indexes.indexOf(setDestId), setDestNew);

                    System.out.println("Replaced the destination for package " + setDestId + " to " + setDestNew);
                    break;

                default:
                    System.out.println("Unknown option.");
                    continue;
            }
        }
    }

    private static void update()
    {
        // What a funny Java moment.
        int[] idArray = indexes.stream().mapToInt(Integer::intValue).toArray();
        String[] destArray = new String[destinations.size()];

        destinations.toArray(destArray);
        Helper.updateDatabase(idArray, destArray);

        System.out.println("Synced Helper database.");
    }

    private static final Random rand = new Random();
    private static final String[] streetNames =
    {
        "Mediterranean Avenue",
        "Baltic Avenue",
        "Oriental Avenue",
        "Vermont Avenue",
        "Connecticut Avenue",
        "St. Charles Place",
        "States Avenue",
        "Virginia Avenue",
        "St. James Place",
        "Tennessee Avenue",
        "New York Avenue",
        "Kentucky Avenue",
        "Indiana Avenue",
        "Illinois Avenue",
        "Atlantic Avenue",
        "Ventnor Avenue",
        "Marvin Gardins",
        "Pacific Avenue",
        "North Carolina Avenue",
        "Pennsylvania Avenue",
        "Park Place",
        "Boardwalk"
    };
    private static final String[] stateNames =
    {
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "District of Columbia",
        "Florida",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Puerto Rico",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Virgin Islands",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming"
    };

    private static int randomId()
    {
        return rand.nextInt(0, 1000);
    }
    private static String randomStreet()
    {
        int number = Math.abs(rand.nextInt(1, 10_000)),
            zip = Math.abs(rand.nextInt(10_000, 100_000));
        String street = streetNames[rand.nextInt(streetNames.length)],
               state = stateNames[rand.nextInt(stateNames.length)];

        return number + " " + street + ", " + state + " " + zip;
    }
}
