// The helper class for the first hackathon of the Programming Club.
// You probably shouldn't modify stuff that's already there for you.

public class Helper
{
    // The helper database. Only synced to the Runner's database by the
    // `updateDatabase(int[], String[])` method.
    private static int[] ids = new int[0]; // The IDs of the packages.
    private static String[] packages = new String[0]; // The destinations of the packages.

    public static void updateDatabase(int[] ids, String[] packages)
    {
        // TODO
        // Update your database of IDs and package destinations.
    }

    public static boolean containsId(int id)
    {
        // TODO
        // Check if the database of IDs contain the `id` parameter.
        // Returns `true` if the database of IDs does contain it, `false` otherwise.
    }

    public static int[] getAllIds()
    {
        // TODO
        // Returns all of the IDs in the database.
    }

    public static String[] getAllPackages()
    {
        // TODO
        // Returns all of the packages in the database.
    }
    
    public static String getPackage(int id)
    {
        // TODO
        // Get the package with a corresponding ID that is equal to `id`.
        // Returns the package's destination found in the string array.
    }

    public static void updatePackage(int id, String newPackage)
    {
        // TODO
        // Replaces the destination of a package with a corresponding ID that is equal to `id` with `newPackage`.
    }
}
